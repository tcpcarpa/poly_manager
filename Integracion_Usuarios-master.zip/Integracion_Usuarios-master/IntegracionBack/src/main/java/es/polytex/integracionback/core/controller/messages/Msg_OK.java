package es.polytex.integracionback.core.controller.messages;

public interface Msg_OK {
    String SUCCESS_TRANSACTION = "Transaction added successfully.";
    String SUCCESS_SITES = "Sites are loadded successfully.";
    String USER_EXIST = "User Exists on Data.";


}
