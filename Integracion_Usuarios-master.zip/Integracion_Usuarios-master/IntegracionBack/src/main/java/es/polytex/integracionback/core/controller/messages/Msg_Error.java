package es.polytex.integracionback.core.controller.messages;

public interface Msg_Error {
    String USER_NO_EXIST = "The user doesn't exists.";
    String SITES_EMPTY = "The User don`t have any Sites.";
    String ERROR_ADD_TRANSACTION = "The transaction is NOT added successfully.";
    String ERROR_STATION_CONNECTION_INFO = "The request to get Connection Information in PM8 is NOT successfully.";


}
