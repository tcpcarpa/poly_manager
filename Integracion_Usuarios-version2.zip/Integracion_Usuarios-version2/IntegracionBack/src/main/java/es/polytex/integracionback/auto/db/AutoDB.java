package es.polytex.integracionback.auto.db;

import es.polytex.integracionback.core.db.DB;

public class AutoDB extends DB {






}
