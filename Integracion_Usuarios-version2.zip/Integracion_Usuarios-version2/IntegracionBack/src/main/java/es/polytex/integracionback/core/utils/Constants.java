package es.polytex.integracionback.core.utils;

public class Constants {
 public static final String API = "https://external-api.polytex.cloud/api/v1";
 public static final String SITES = "/Site/getAll";
 public static final String IMPORT = "/User/import";
 public static final String LOGIN = "/Identity/login";

}
