package es.polytex.integracionback.ldap.service;

import es.polytex.integracionback.core.service.Service;

public class LdapService extends Service {
}
