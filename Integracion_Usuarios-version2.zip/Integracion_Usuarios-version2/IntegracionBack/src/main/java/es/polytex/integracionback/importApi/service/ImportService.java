package es.polytex.integracionback.importApi.service;

import es.polytex.integracionback.core.service.Service;

public class ImportService extends Service {
}
