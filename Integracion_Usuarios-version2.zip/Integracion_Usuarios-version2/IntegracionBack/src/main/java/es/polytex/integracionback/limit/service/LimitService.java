package es.polytex.integracionback.limit.service;

import es.polytex.integracionback.core.service.Service;

public class LimitService extends Service {
}
