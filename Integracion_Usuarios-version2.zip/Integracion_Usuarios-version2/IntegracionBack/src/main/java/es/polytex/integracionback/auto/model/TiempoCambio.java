package es.polytex.integracionback.auto.model;

public class TiempoCambio {
    private Tiempo tiempo;

    public TiempoCambio() {
    }
    public TiempoCambio(Tiempo tiempo) {
        this.tiempo = tiempo;
    }

    public Tiempo getTiempo() {
        return tiempo;
    }
}
