package es.polytex.integracionback.ldap.db;

import es.polytex.integracionback.core.db.DB;

public class LdapDB extends DB {
}
