package es.polytex.integracionback.files.service;

import es.polytex.integracionback.core.service.Service;

public class FilesService extends Service {

}






