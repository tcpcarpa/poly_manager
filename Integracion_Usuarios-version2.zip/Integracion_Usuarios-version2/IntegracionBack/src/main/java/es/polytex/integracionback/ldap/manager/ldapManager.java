package es.polytex.integracionback.ldap.manager;

import es.polytex.integracionback.core.manager.Manager;

public class ldapManager extends Manager {
}
