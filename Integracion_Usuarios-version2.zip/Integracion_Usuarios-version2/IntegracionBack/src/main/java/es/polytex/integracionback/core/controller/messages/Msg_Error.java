package es.polytex.integracionback.core.controller.messages;

public interface Msg_Error {
    String USER_NO_EXIST = "The user doesn't exists.";
    String NO_INET_CONECT = "No internet Conection.";
    String SITES_EMPTY = "The User don`t have any Sites.";
    String SITES_NO_EXISTS = "This site doesn't exist.";
    String USERDEFINITION_NO_EXISTS = "This site don't have any userdefinition Object.";
    String ERROR_ADD_TRANSACTION = "The transaction is NOT added successfully.";
    String ERROR_PERMISION = "Not user granted for transacción.";

}
