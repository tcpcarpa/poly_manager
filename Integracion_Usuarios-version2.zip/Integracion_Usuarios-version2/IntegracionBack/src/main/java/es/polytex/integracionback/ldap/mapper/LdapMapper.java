package es.polytex.integracionback.ldap.mapper;

import es.polytex.integracionback.core.mapper.Mapper;

public class LdapMapper extends Mapper {
}
