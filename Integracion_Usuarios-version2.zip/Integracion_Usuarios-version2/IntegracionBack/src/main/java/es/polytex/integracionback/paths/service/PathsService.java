package es.polytex.integracionback.paths.service;

import es.polytex.integracionback.core.service.Service;

public class PathsService extends Service {
}
