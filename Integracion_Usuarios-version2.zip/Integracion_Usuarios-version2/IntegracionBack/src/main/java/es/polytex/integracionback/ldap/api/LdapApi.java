package es.polytex.integracionback.ldap.api;

import es.polytex.integracionback.core.api.Cors;

public class LdapApi extends Cors {
}
