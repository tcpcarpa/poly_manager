package es.polytex.integracionback.userDefinition.service;

public class UserDefService {
}
